import pandas
import numpy
import nltk
from nltk.sentiment.vader import SentimentIntensityAnalyzer

data1=pandas.read_csv('../CCC_TrainingData_csv.csv')
wordCloud=pandas.read_csv('../wordCloud.csv', encoding='utf-8')

nltk.download('words')
nltk.download('vader_lexicon')

dicti = set(nltk.corpus.words.words())
#print(len(dicti.split()))
Analyzer = SentimentIntensityAnalyzer()
lenx=[]
wc_happy=[]
wc_sad=[]
leny=[]
review=[]
sentiment_score=[]
sentiment_score_1=[]



print("Adding NLTK's Sentiment Score")

for index,datasend in data1.iloc[:,3:4].iterrows():	
		a=(datasend)
		a=str(a)
		#print(a)		
		sentiment = Analyzer.polarity_scores(a)
		#print(sentiment)
		sentiment=sentiment['compound']
		sentiment_score.append(sentiment)
		#print(sentiment)

print("Added")

print("Strarting some heavy nlp shit")
for sent in data1['Commentary']:

	c_happy=0
	c_sad=0
	c_count=0
	lenx.append(len(sent.split()))
	rev=[]
	for word in sent.split():
		word=str(word.lower())
		#print(word)
		if(word in dicti):
			rev.append(word)
			c_count+=1			
		if(word in wordCloud['Happy_101'].tolist()):
			c_happy+=1
			#print('Found ' + str(word))
		elif(word in wordCloud['Sad_101'].tolist()):
			c_sad+=1
			#print('Found Sad:- ' + str(word))
	wc_happy.append(c_happy)
	wc_sad.append(c_sad)
	review.append(" ".join(rev))
	leny.append(c_count)





data1['text_cleansed']=review
data1['happy_count']=wc_happy
data1['sad_count']=wc_sad
data1['original_count']=lenx
data1['cleansed_count']=leny
data1['sentiment_compound']=sentiment_score

counter=0
print("Adding NLTK's Sentiment Score Again")
for index,datasend in data1.iloc[:,4:5].iterrows():
#for index,datasend in data1.iloc[:,2:3].iterrows():

		
		a=(datasend)
		counter+=1
		a=str(a)		
		if(counter < 10):
			print(a)
		sentiment = Analyzer.polarity_scores(a)
		#print(sentiment)
		sentiment=sentiment['compound']
		sentiment_score_1.append(sentiment)
		#print(sentiment)

data1['Sentiment_compund_1']=sentiment_score_1
data1.to_csv('../Processed/Cleansed_Train_1.csv' , index=False)
