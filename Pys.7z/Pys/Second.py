#Cleansed_Train_1.csv

import pandas as pd
from sklearn.feature_extraction.text import TfidfVectorizer
from nltk.corpus import stopwords
from wordcloud import WordCloud
import matplotlib.pyplot as plt
import nltk
from nltk.tokenize import word_tokenize
from sklearn.naive_bayes import MultinomialNB
from sklearn.pipeline import Pipeline
from sklearn.model_selection import GridSearchCV
from sklearn.feature_extraction.text import CountVectorizer
from sklearn.feature_extraction.text import TfidfTransformer
from sklearn.linear_model import SGDClassifier


if __name__ == '__main__':
	df_main= pd.read_csv('../Processed/Cleansed_Train_1.csv' , nrows=1000)


	reviews = df_main.Commentary.str.cat(sep=' ')


	stop_words = (stopwords.words('english'))
	stop_words.append('-999')
	stop_words.append('- 999')
	tokens = word_tokenize(reviews)
	tokens = [w for w in tokens if not w in stop_words]


	vocabulary = set(tokens)
	print(len(vocabulary))
	frequency_dist = nltk.FreqDist(tokens)
	sorted(frequency_dist,key=frequency_dist.__getitem__, reverse=True)[0:50]

	wordcloud = WordCloud(width=1600, height=800).generate_from_frequencies(frequency_dist)
	plt.figure(figsize=(20,10), facecolor='k')
	plt.imshow(wordcloud)

	plt.axis("off")
	#plt.show()


	df_main_zero=df_main[df_main.Over_Run_Total== 0]
	df_main_rest=df_main[df_main.Over_Run_Total!= 0]
	
	text_clf = Pipeline([('vect', CountVectorizer(stop_words='english')),
	                      ('tfidf', TfidfTransformer()),
	                      ('clf', MultinomialNB()),

	                      #('clf-svm', SGDClassifier()),

	 ])

	parameters = {'vect__ngram_range': [(1, 1), (1, 2)], 'tfidf__use_idf': (True, False),'clf__alpha': (1e-2, 1e-3),, }
	gs_clf = GridSearchCV(text_clf, parameters, n_jobs=-1)
	gs_clf = gs_clf.fit(df_main.Commentary, df_main.Target)
	print("Score:- ")
	print(gs_clf.best_score_)	
	print(gs_clf.best_params_)

	'''
	 from sklearn.linear_model import SGDClassifier
	 text_clf_svm = Pipeline([('vect', CountVectorizer()),
	                      ('tfidf', TfidfTransformer()),
	                      ('clf-svm', SGDClassifier(loss='hinge', penalty='l2',
	                                            alpha=1e-3, n_iter=5, random_state=42)),
	])
	_ = text_clf_svm.fit(twenty_train.data, twenty_train.target)
	predicted_svm = text_clf_svm.predict(twenty_test.data)
	np.mean(predicted_svm == twenty_test.target)

	'''


	#text_clf = text_clf.fit(df_main.Commentary, twenty_train.target)

	# predicted = text_clf.predict(twenty_test.data)
	# encode document
	
	df_main.corr().to_csv('Interim.csv' , index=False)


