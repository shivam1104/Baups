from keras.models import Model
from keras.layers import Dense,Activation,Conv1D,MaxPooling1D,Flatten,Input
import numpy as np
from keras.optimizers import SGD
from keras.utils import plot_model
from keras.layers import Conv2D, MaxPooling2D
import keras
import pydot
import pydotplus
from keras.utils.vis_utils import model_to_dot
keras.utils.vis_utils.pydot = pydot

import os
os.environ["PATH"] += os.pathsep + 'C:\\Program Files (x86)\\Graphviz2.38\\bin\\'

# input_img = Input(shape = (X.shape[1], X.shape[2], Dims))
input_img = Input(shape= (128, 4))

#First distribution
tower_1 = Conv1D(1, 1,padding='same', activation='relu')(input_img)
tower_1 = Conv1D(8, 4,padding='same', activation='relu')(tower_1)
tower_1 = Conv1D(16, 4,padding='same', activation='relu')(tower_1)
tower_1 = Conv1D(32, 4,padding='same', activation='relu')(tower_1)


tower_2 = Conv1D(1, 1, padding='same', activation='relu')(input_img)
tower_2 = Conv1D(16, 8,padding='same', activation='relu')(tower_2)
tower_2 = Conv1D(32, 8,padding='same', activation='relu')(tower_2)

tower_3 = Conv1D(1, 1, padding='same', activation='relu')(input_img)
tower_3 = Conv1D(32, 16, padding='same', activation='relu')(tower_3)

tower_4 = MaxPooling1D(4, strides=1, padding='same')(input_img)
tower_4 = Conv1D(32, 32, padding='same', activation='relu')(tower_4)

tower_5 = Conv1D(1, 1, padding='same', activation='relu')(input_img)


output_1 = keras.layers.concatenate([tower_1, tower_2, tower_3, tower_4, tower_5], axis = 2)


#Second distribution
tower_1 = Conv1D(1, 1,padding='same', activation='relu')(output_1)
tower_1 = Conv1D(8, 4,padding='same', activation='relu')(tower_1)
tower_1 = Conv1D(16, 4,padding='same', activation='relu')(tower_1)
tower_1 = Conv1D(32, 4,padding='same', activation='relu')(tower_1)
tower_2 = Conv1D(1, 1, padding='same', activation='relu')(output_1)
tower_2 = Conv1D(16, 8,padding='same', activation='relu')(tower_2)
tower_2 = Conv1D(32, 8,padding='same', activation='relu')(tower_2)

tower_3 = Conv1D(1, 1, padding='same', activation='relu')(output_1)
tower_3 = Conv1D(32, 16, padding='same', activation='relu')(tower_3)


output_2 = keras.layers.concatenate([tower_1, tower_2, tower_3], axis = 2)

#Third Distribution
tower_1 = Conv1D(1, 1,padding='same', activation='relu')(output_2)
tower_1 = Conv1D(8, 3,padding='same', activation='relu')(tower_1)
tower_1 = Conv1D(16, 5,padding='same', activation='relu')(tower_1)
tower_1 = Conv1D(32, 5,padding='same', activation='relu')(tower_1)


tower_2 = Conv1D(1, 1, padding='same', activation='relu')(output_2)
tower_2 = Conv1D(16, 4,padding='same', activation='relu')(tower_2)
tower_2 = Conv1D(32, 4,padding='same', activation='relu')(tower_2)

tower_3 = Conv1D(1, 1, padding='same', activation='relu')(output_2)
tower_3 = Conv1D(64, 8, padding='same', activation='relu')(tower_3)

tower_4 = MaxPooling1D(4, strides=1, padding='same')(output_2)
tower_4 = Conv1D(16, 30, padding='same', activation='relu')(tower_4)


output = keras.layers.concatenate([tower_1, tower_2, tower_3, tower_4], axis = 2)


output = Flatten()(output) #FC 
#output = Flatten()(output) #FC 
out    = Dense(6, activation='softmax')(output) #Dense = 

'''
output = Flatten()(output_1)
out    = Dense(6, activation='softmax')(output)
'''
model = Model(inputs = input_img, outputs = out)
print(model.summary())

plot_model(model, to_file='model_simple.png')


# model.compile(loss='categorical_crossentropy', optimizer='adam', metrics=['accuracy'])
# model.fit(X_train, y_train, validation_data=(X_test, y_test), epochs=20, batch_size=32)