import re 

'''
w- Alpha Numeric 
d- Digits
s- Space
'''

string2='9844309876 ,9844309876 ,9844309876 ,9844309876'
string3='58443098'
string1="Hi&This&iiis&an&MLasas&Pool&anMLSession.&We&MLrane&leaMLrning&Regex."
#x=re.search('^Hi&',&string1)

r'\w+'
print(string1)
x=(re.findall(r'\AML',string1))
#x=(re.findall(r'',&string1))
print(x)
print((len(x)))




'''
print(re.findall(r'\w+', string1))

print(re.findall(r'\w*', string1))

print(re.findall(r'\s?', string1))
'''





