from sklearn.ensemble import RandomForestRegressor
from sklearn.ensemble import GradientBoostingRegressor
from sklearn.model_selection import train_test_split
import pandas as pd
import pickle
import numpy as np
from sklearn.svm import SVR
from xgboost import XGBRegressor
import chardet

path=""

with open("OK\\TESTONME_1.csv", 'rb') as f:
    result = chardet.detect(f.read())  # or readline if the file is large


#wordCloud=pd.read_csv('wordCloud.csv', encoding=result['encoding'])

print(result)

main_data = pd.read_csv(path + "OK\\TRAINONME.csv" , low_memory=False, nrows=1 ,encoding='utf-8')
aur_bhi_main_1 = pd.read_csv(path + "OK\\TESTONME_1.csv" , low_memory=False, nrows=1,encoding=result['encoding'])


numerics = ['uint8','int16', 'int32', 'int64', 'float16', 'float32', 'float64']
#ML PART
train_y_1 = main_data.Zomato_user_rating.values#['labels']
train_x_1 = main_data.drop('Zomato_user_rating', axis = 1)
train_x_1=train_x_1.drop('id', axis = 1)
#train_x_1=train_x_1.select_dtypes(include=numerics)
train_x_2=train_x_1.values


aur_bhi_main_1=aur_bhi_main_1.select_dtypes(include=numerics)
aur_bhi_main=aur_bhi_main_1.drop('id', axis=1)
aur_bhi_main=aur_bhi_main.values



train_x_1_1, test_x_1, train_y_1_1, test_y_1 = train_test_split(train_x_2 ,train_y_1 ,test_size=0.1)


#input()

n_est=7013
n_job=40


print("Starting GB Regressor  with n_estimators as  10000  X" + str(n_est) +" and n_jobs as " + str(n_job))
regr = GradientBoostingRegressor( n_estimators = 7000 , verbose=1)#, n_jobs=n_job)
regr.fit(train_x_1_1, train_y_1_1)
with open('GBR_'+str(n_est)+'.pkl' ,'wb') as f:
    pickle.dump(regr, f) 

print(regr.score(test_x_1, test_y_1))
pred_rf = regr.predict(test_x_1)
rmse = str(np.sqrt(np.mean((test_y_1 - pred_rf)**2)))
print(rmse)




print("Starting Predicting")
predictions = regr.predict(aur_bhi_main)
print(predictions)
submission = pd.DataFrame(np.column_stack([aur_bhi_main_1.id, predictions]), columns = ['id','Zomato_user_rating'])
submission.to_csv('GBR1_'+str(n_est)+'.csv', index = False)

f.close()


print("Starting RF Regressor  with n_estimators as " + str(n_est) +" and n_jobs as " + str(n_job))
regr = RandomForestRegressor( n_estimators = n_est , verbose=1 , n_jobs=n_job)
regr.fit(train_x_1_1 ,train_y_1_1)

with open('REGRR_2.pkl', 'wb') as f:
    pickle.dump(regr, f) 

print(regr.score(test_x_1 ,test_y_1))


pred_rf = regr.predict(test_x_1)
rmse = str(np.sqrt(np.mean((test_y_1 - pred_rf)**2)))
print(rmse)



print("Starting Predicting")
predictions = regr.predict(aur_bhi_main)


submission = pd.DataFrame(np.column_stack([aur_bhi_main_1.id, predictions]), columns = ['id','Zomato_user_rating'])
submission.to_csv('REGR1_'+str(n_est)+'.csv', index = False)
f.close()


print("Starting XG Boost Regressor  with n_estimators as  10000 X" + str(n_est) +" and n_jobs as " + str(n_job))
regr = XGBRegressor( n_estimators = 10000 , verbose=3 , n_jobs=n_job)
regr.fit(train_x_1_1 ,train_y_1_1)

with open('XGBOOST_2.pkl', 'wb') as f:
    pickle.dump(regr, f) 

print(regr.score(test_x_1 ,test_y_1))


pred_rf = regr.predict(test_x_1)
rmse = str(np.sqrt(np.mean((test_y_1 - pred_rf)**2)))
print(rmse)



print("Starting Predicting")
predictions = regr.predict(aur_bhi_main)


submission = pd.DataFrame(np.column_stack([aur_bhi_main_1.id, predictions]), columns = ['id','Zomato_user_rating'])
submission.to_csv('XG1_'+str(n_est)+'.csv', index = False)
f.close()


