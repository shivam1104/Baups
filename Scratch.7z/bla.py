import h2o
from h2o.automl import H2OAutoML
import pandas as pd

h2o.init(max_mem_size_GB=5)

# Import a sample binary outcome train/test set into H2O
train = h2o.import_file("OK\\TRAINONME.csv")
test = h2o.import_file("OK\\TESTONME.csv")

# Identify predictors and response
x = train.columns
y = "Zomato_user_rating"
x.remove(y)
'''
# For binary classification, response should be a factor
train[y] = train[y].asfactor()
test[y] = test[y].asfactor()
'''
# Run AutoML for 20 base models (limited to 1 hour max runtime by default)
aml = H2OAutoML(max_models=6, seed=8, max_runtime_secs=18000)
aml.train(x=x, y=y, training_frame=train)

# View the AutoML Leaderboard
lb = aml.leaderboard
print(lb)
print("DAMMNNN!!!")
print(lb.head(rows=lb.nrows))  # Print all rows instead of default (10 rows)


# The leader model is stored here

print("Printing Leader Model")
print(aml.leader)

# If you need to generate predictions on a test set, you can make
# predictions directly on the `"H2OAutoML"` object, or on the leader
# model object directly

preds = aml.predict(test)

print("Printing aml.Predict")
print(preds)
print("DONE")

list1=[]
list1=h2o.as_list(preds['predict'])
#print(list1)

print("BLA")

gp_as_pandas_test = h2o.as_list(test)

submission1=pd.DataFrame()
submission1['id']=gp_as_pandas_test['id']
submission1['Zomato_user_rating']=list1
submission1.to_csv('Upload_me_Random_1_1.csv')

print("One file Done")

# or:
preds1 = aml.leader.predict(test)

print("Printing aml.leader.Predict")
print(preds1)
print("DONE")
list1=[]
list1=h2o.as_list(preds1['predict'])
#print(list1)


#gp_as_pandas_test = h2o.as_list(test_data)
submission1=pd.DataFrame()
submission1['id']=gp_as_pandas_test['id']
submission1['Zomato_user_rating']=list1
submission1.to_csv('Upload_me_Random_2_1.csv')

print("BLA")

print("Second file Done")


h2o.save_model(aml.leader, path = '')