import pandas as pd

filenameTrain='Binned_intermediate_Preprocessed_Eatery_TrainingData.csv'
filenameTest='Binned_intermediate_Preprocessed_Eatery_TestData.csv'
path=''
data1=pd.read_csv(path + filenameTest, low_memory=False)
data_intersect = pd.read_csv(path + filenameTrain, low_memory=False)

print("Printing Trained")
print(data_intersect.info())
#input("THIK?")
print("Printing Test")
print(data1.info())

#df = df1[df1.columns.intersection(df2.columns)]
#df = df1[df1.columns.isin(df2.columns)]
#df1.reindex(columns=df2.columns)

data_intersect=data_intersect.reindex(columns=data1.columns)
print(data_intersect.info())
data_intersect.to_csv('TRAINONME.csv',index=False)


data_intersect = pd.read_csv(path + filenameTrain, low_memory=False)
data1.reindex(columns=data_intersect.columns)
data1.to_csv('TESTONME.csv')

print("Wohooo Done")

import SampleMLModels

