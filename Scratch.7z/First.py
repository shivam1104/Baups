import pandas
import pickle
import numpy as np
from fuzzywuzzy import process, fuzz
import string
import nltk
import re
from sklearn.feature_extraction.text import TfidfVectorizer
from autocorrect import spell 
import chardet
from nltk.sentiment.vader import SentimentIntensityAnalyzer
from textblob import TextBlob
from nltk.corpus import stopwords

#filename='Eatery_TrainingData.csv'
filename='Eatery_TestData.csv'

main_data=pandas.read_csv(filename)#,nrows=10)


#train_Data=pandas.read_csv(filename)#,nrows=10)


print(main_data.info())
main_data = main_data.replace({' ':''}, regex=True)

main_data = main_data.drop('is_delivering_now' , axis=1)
main_data = main_data.drop('user_rating__custom_rating_text_background' , axis=1)
main_data = main_data.drop('user_rating__custom_rating_text' , axis=1)
main_data['location__city_id'>'900']='0'
main_data['location__country_id'>'900']='0'
main_data['origin_cc_1']=(main_data['location__country_id']*1000) + (main_data['location__city_id'])
#main_data = main_data.drop('location__city' , axis=1)
main_data = main_data.drop('location__city_id' , axis=1)
main_data = main_data.drop('location__country_id' , axis=1)
print('Working...')

main_data['has_image'] = np.where(main_data['featured_image'] is None, '0', '1')
main_data = main_data.drop('featured_image' , axis=1)
main_data['has_thumb'] = np.where(main_data['thumb'] is None, '0', '1')
main_data = main_data.drop('thumb' , axis=1)
main_data['has_medio'] = np.where(main_data['medio_provider'] is None, '0', '1')
main_data = main_data.drop('medio_provider' , axis=1)
main_data['is_new'] = np.where(main_data['user_rating__rating_tool_tip'] is None, '0', '1')
main_data = main_data.drop('user_rating__rating_tool_tip' , axis=1)
main_data['had_events'] = np.where(main_data['zomato_events'] is None, '0', '1')
main_data = main_data.drop('zomato_events' , axis=1)
main_data['has_offers'] = np.where(main_data['offers'] is None, '0', '1')
main_data = main_data.drop('offers' , axis=1)




#main_data = main_data[main_data["user_rating__rating_text"] != 'Notrated']
#main_data = main_data[main_data["user_rating__rating_text"] != 'Belumadapenilaian']



main_data['BestPrice']=100000*(main_data['price_range']) + main_data['average_cost_for_two']

main_data = main_data.drop('price_range' , axis=1)
main_data = main_data.drop('average_cost_for_two' , axis=1)
main_data = main_data.drop('location__zipcode' , axis=1)

main_data['mezzo_provider'] = main_data['mezzo_provider'].fillna(value=0)

print(main_data.info())
print('Starting One Hot Encoding')

categorical = ['mezzo_provider','origin_cc_1','currency','include_bogo_offers','establishment_types__establishment_type__id']

main_data = pandas.get_dummies(main_data, columns = categorical)

main_data.to_csv('Preprocessed_' + filename,index=False)

print("Importing Word Play")
import wordPlay

