import pandas as pd
import numpy as np


#filename='intermediate_Preprocessed_Eatery_TrainingData.csv'
filename='intermediate_Preprocessed_Eatery_TestData.csv'

path=''

data_train = pd.read_csv(path + filename , low_memory=False)

step = 0.2
to_bin = lambda x: np.floor(np.floor(x / step) * step)
data_train["latbin"] = data_train.location__latitude.map(to_bin)
data_train["lonbin"] = data_train.location__longitude.map(to_bin)
#groups = data_train.groupby(("latbin", "lonbin"))
data_train=data_train.drop('location__latitude',axis=1)
data_train=data_train.drop('location__longitude',axis=1)
data_train["LatLong"]= data_train["latbin"].map(str)+data_train["lonbin"].map(str)
#dataframe["period"] = dataframe["Year"].map(str) + dataframe["quarter"]

#print(groups.value()#)
#data_train["group"]=groups

print("Hotting now")

categorical = ['LatLong','latbin','lonbin']
data_train = pd.get_dummies(data_train, columns = categorical)


data_train.to_csv('Binned_'+filename,index=False)

print("Calling Merger")
import mergeMe
