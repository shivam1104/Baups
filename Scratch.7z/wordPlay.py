import pandas as pd
from fuzzywuzzy import process, fuzz
import string
import nltk
import re
from sklearn.feature_extraction.text import TfidfVectorizer
from autocorrect import spell 
import chardet
from nltk.sentiment.vader import SentimentIntensityAnalyzer
from textblob import TextBlob
from nltk.corpus import stopwords

filename='Preprocessed_Eatery_TestData.csv'
#filename='Preprocessed_Eatery_TrainingData.csv'

path=''

data_train = pd.read_csv(path + filename , low_memory=False)
with open('wordCloud.csv', 'rb') as f:
    result = chardet.detect(f.read())  # or readline if the file is large


wordCloud=pd.read_csv('wordCloud.csv', encoding=result['encoding'])



lenx=[]
wc_happy=[]
wc_sad=[]
leny=[]
review=[]
c_hash=0
counter_hash=[]
c_abuse=0
counter_abouse=[]
wc_unkn=[]

#data_train['user_rating__rating_text'].str.lower.replace('$&@*#', 'TERRIBLE', inplace=True)

# create the transform
# column you are working onprint
stopword_set = set(stopwords.words("english"))
dicti = set(nltk.corpus.words.words())

#user_rating__rating_text

data_train.user_rating__rating_text = data_train.user_rating__rating_text.str.replace('[^a-zA-Z]', '')
data_train.user_rating__rating_text = data_train.user_rating__rating_text.apply(lambda x: str(x).lower())
data_train.user_rating__rating_text = data_train.user_rating__rating_text.apply(lambda x: str(x).translate(string.punctuation))
data_train.user_rating__rating_text = data_train.user_rating__rating_text.apply(lambda x: str(x).translate(string.digits))

'''
data_train.cuisines = data_train.cuisines.str.replace('[^a-zA-Z]', '')
data_train.cuisines = data_train.cuisines.apply(lambda x: str(x).lower())
data_train.cuisines = data_train.cuisines.apply(lambda x: str(x).translate(string.punctuation))
data_train.cuisines = data_train.cuisines.apply(lambda x: str(x).translate(string.digits))
'''



data_train.name = data_train.name.apply(lambda x: str(x).lower())
data_train.establishment_types__establishment_type__name = data_train.establishment_types__establishment_type__name.apply(lambda x: str(x).lower())
data_train.location__locality_verbose = data_train.location__locality_verbose.apply(lambda x: str(x).lower())
fuzzy_name_est=[]
fuzzy_name_loc=[]
fuzzy_name_cui=[]
rating_code=[]
goodlist=['good','bom','buono','bueno']
verygoodlist=['verygood','harika','Ã‡okiyi','bardzodobrze','ortalama','sangatbaik','velmidobrÃ©']
poorlist=[]
averagelist=[]

#user_rating__votes
for index, row in data_train.iterrows():
	rpt=fuzz.ratio(str(row['name']), str(row['establishment_types__establishment_type__name']))
	ptr=fuzz.partial_ratio(str(row['name']), str(row['establishment_types__establishment_type__name']))
	trp=fuzz.token_sort_ratio(str(row['name']), str(row['establishment_types__establishment_type__name']))
	sum1=rpt+ptr+trp
	fuzzy_name_est.append(sum1)

	rpt=fuzz.ratio(str(row['name']), str(row['location__locality_verbose']))
	ptr=fuzz.partial_ratio(str(row['name']), str(row['location__locality_verbose']))
	trp=fuzz.token_sort_ratio(str(row['name']), str(row['location__locality_verbose']))
	sum1=rpt+ptr+trp
	fuzzy_name_loc.append(sum1)

	rpt=fuzz.ratio(str(row['name']), str(row['cuisines']))
	ptr=fuzz.partial_ratio(str(row['name']), str(row['cuisines']))
	trp=fuzz.token_sort_ratio(str(row['name']), str(row['cuisines']))
	sum1=rpt+ptr+trp
	fuzzy_name_cui.append(sum1)

	if(row['user_rating__rating_text'] in goodlist ):
		rating_code.append(3000+row['user_rating__votes'])
	elif(row['user_rating__rating_text'] in verygoodlist):
		rating_code.append(4000+row['user_rating__votes'])
	elif(row['user_rating__rating_text'] == 'excelente' or  row['user_rating__rating_text'] =='excellent' or row['user_rating__rating_text'] =='eccellente' or row['user_rating__rating_text'] =='biasa'):
		rating_code.append(5000+row['user_rating__votes'])
	elif(row['user_rating__rating_text']=='average'):
		rating_code.append(2000+row['user_rating__votes'])

	elif(row['user_rating__rating_text']=='notrated'):
		rating_code.append('0')
	elif(row['user_rating__rating_text']=='poor' or row['user_rating__rating_text']=='priemer'):
		rating_code.append(1000+row['user_rating__votes'])
	else:
		rating_code.append(4000++row['user_rating__votes'])
		print(row['user_rating__rating_text'])

print("Strarting some heavy nlp shit on Training Data")
#cuisines


for sent in data_train['cuisines']:
	sent=str(sent)
	c_happy=0
	c_sad=0
	c_count=0
	c_abuse=0
	c_unkn=0
	c_hash=sent.count(',')
	counter_hash.append(c_hash)

	lenx.append(len(sent.split()))
	rev=[]
	for word in sent.split():
		word=(str(str(word).lower()))
		
		if(word in dicti):
			rev.append(word)
			c_count+=1			
		if(word in wordCloud['Happy_101'].tolist()):
			c_happy+=1
			#print('Found ' + str(word))
		elif(word in wordCloud['Sad_101'].tolist()):
			c_sad+=1
		elif(word in wordCloud['Abuse_101'].tolist()):			
			c_abuse+=1
		else:
			c_unkn+=1

			#print('Found Sad:- ' + str(word))
	wc_happy.append(c_happy)
	counter_abouse.append(c_abuse)
	wc_sad.append(c_sad)
	review.append(" ".join(rev))
	leny.append(c_count)
	wc_unkn.append(c_unkn)

#data_train['text_cleansed']=review
#data_train['happy_count']=wc_happy
#data_train['sad_count']=wc_sad
data_train['original_count']=lenx
#data_train['abuse_count']=counter_abouse
data_train['counter_hash']=counter_hash
data_train['Unknowns']=wc_unkn
data_train['fuzzy_name_est']=fuzzy_name_est
data_train['fuzzy_name_loc']=fuzzy_name_loc
data_train['fuzzy_name_cui']=fuzzy_name_cui
data_train['Rating_Text']=rating_code


categorical = ['user_rating__rating_text']
data_train = pd.get_dummies(data_train, columns = categorical)

#data_train = data_train.drop('user_rating__rating_text' , axis=1)
data_train = data_train.drop('name' , axis=1)
data_train = data_train.drop('establishment_types__establishment_type__name' , axis=1)
data_train = data_train.drop('location__locality_verbose' , axis=1)
data_train = data_train.drop('location__address' , axis=1)
data_train = data_train.drop('location__city' , axis=1)
data_train = data_train.drop('location__locality' , axis=1)

'''
##################################
data_train = data_train.drop('location__latitude' , axis=1)
data_train = data_train.drop('location__longitude' , axis=1)
##################################
'''





data1 = data_train

amenities=data1['cuisines'].values
setcu=set(amenities)
#print(setcu)

cuisinelist=['Kaak', 'Ethiopian', 'EasternAnatolia', 'HakkaChinese', 'Lounge', 'Crepes', 'Hyderabadi', 'French', 'Dumplings', 'Gujarati', 'Mongolian', 'Palembang', 'Cafeteria', 'FastFood', 'Colombian', 'Emirati', 'Czech', 'EasternEuropean', 'Belanda', 'Kumpir', 'Soto', 'ÇiğKöfte', 'Deli', 'DimSum', 'Chettinad', 'Nikkei', 'Mexican', 'Mediterranean', 'Fondue', 'Shanghai', 'SouthAfrican', 'Caribbean', 'Giblets', 'PanAsian', 'Korean', 'German', 'Paan', 'Egyptian', 'Syrian', 'Pho', 'Brazilian', 'StreetFood', 'NorthIndian', 'Contemporary', 'GourmetFastFood', 'Teochew', 'Peranakan', 'Irish', 'HongKongStyle', 'Iranian', 'African', 'Bagels', 'Teppanyaki', 'Hokkien', 'Tex-Mex', 'Kebab', 'Sandwich', 'Continental', 'Armenian', 'Tibetan', 'Hawaiian', 'Nepalese', 'Shawarma', 'RawMeats', 'ModernEuropean', 'Swiss', 'Saj', 'Spanish', 'Mozambican', 'Thai', 'Durban', 'Ottoman', 'Satay', 'PubFood', 'Gaúcha', 'Betawi', 'Maharashtrian', 'European', 'Bangladeshi', 'Balkans', 'Yemeni', 'Curry', 'Sunda', 'Raclette', 'RestaurantCafe', 'Venezuelan', 'IceCream', 'BlackSea', 'Bihari', 'Bakso', 'NorthernChinese', 'Arabian', 'Coffee', 'Tapas', 'Cambodian', 'BubbleTea', 'Seafood', 'Mineira', 'MiddleEastern', 'British', 'Others', 'Bengali', 'CapeMalay', 'CafeFood', 'Goan', 'Tea', 'Bakery', 'Scottish', 'BarFood', 'Argentine', 'Australian', 'Foul', 'AsianFusion', 'Capixaba', 'Indonesian', 'Russian', 'SouthIndian', 'KoreanBBQ', 'Alentejana', 'Madeiran', 'TurkishPizza', 'Pizza', 'Ukrainian', 'FrozenYogurt', 'NorthEastern', 'Moroccan', 'Cantonese', 'Grill', 'Martabak', 'Hainanese', 'Kiwi', 'Andhra', 'Mithai', 'FingerFood', 'HotPot', 'Manakish', 'Malaysian', 'Belgian', 'Mandi', 'Khaleeji', 'Chilean', 'SriLankan', 'WorldCuisine', 'Mishti', 'Burger', 'Fusion', 'HealthyFood', 'Steak', 'Dimsum', 'Falafel', 'Hungarian', 'Portuguese', 'Filipino', 'Italian', 'Awadhi', 'Vietnamese', 'Jamaican', 'Pastry', 'Petiscos', 'Rolls', 'FreshFish', 'Taiwanese', 'Biryani', 'Caipira', 'Peruvian', 'Cajun', 'Cake', 'Aegean', 'Chifa', 'Cuban', 'Roast', 'Chinese', 'Afghan', 'Author', 'Malay', 'Cafe', 'IkanBakar', 'Afghani', 'Mughlai', 'Bakmi', 'Asian', 'ModernIndian', 'YumCha', 'Lucknowi', 'Baiana', 'BBQ', 'Wraps', 'Carvery', 'Mangalorean', 'Breakfast', 'Scandinavian', 'Pilav', 'International', 'Patisserie', 'Pakistani', 'Jewish', 'Swedish', 'Börek', 'FriedChicken', 'Beverages', 'Canadian', 'FishandChips', 'Indian', 'Greek', 'Pacific', 'SouthEast', 'Snacks', 'Singaporean', 'Aceh', 'SnackBar', 'Oriental', 'American', 'Momos', 'CoffeeandTea', 'Döner', 'DrinksOnly', 'Vegetarian', 'Western', 'Kerala', 'Polish', 'Vegan', 'Jawa', 'Southern', 'Empanadas', 'Ramen', 'Home-made', 'Sushi', 'Brasserie', 'Austrian', 'LatinAmerican', 'Desserts', 'OldTurkishBars', 'Rajasthani', 'Minhota', 'Steamboat', 'Turkish', 'Balti', 'Japanese', 'Diner', 'Sichuan', 'Juices', 'Lebanese', 'Izgara', 'Salad', 'nan', 'Burmese']

counter=-1
row_count=-1
cuisinelist1=[]
print("Staring One Hot encoding of Cuisines")
for i in amenities:
	row_count+=1	
	#print("One Hot Encoding row number " + str(row_count))
	splits=str(i).split(',')

	for j in splits:
		cuisinelist1.append(j)
		j=str(j).replace(' ','')
		j=j.lower()

		#data.ix[row_count,j]=1
		data1.ix[row_count,j]=1
'''	
		if j in cuisinelist:
			j=str(j).replace(' ','')
			j=j.lower()
			#data.ix[row_count,j]=1
			data1.ix[row_count,j]=1
'''
print
print("Wooof!")

#print(set(cuisinelist1))

data1=data1.fillna('0')
data1=data1.drop('cuisines',axis=1)

print("Done with the Cuisisnes")
print("Saving")


data1.to_csv('intermediate_'+filename,index=False)



print("Done")

print("Calling Lats Long")
import latslongs

