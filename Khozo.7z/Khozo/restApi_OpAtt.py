from anytree import Node, RenderTree, search, findall_by_attr, findall 
from openpyxl import load_workbook
import spacy
from spacy.lang import en
import gensim
from gensim import parsing
from flask import Flask, render_template, request, redirect, url_for, send_from_directory, send_file, jsonify
app = Flask(__name__)
import os
#from flask import Flask, render_template, request, redirect, url_for, send_from_directory, send_file, jsonify
import re
from glob import glob

import os
from bs4 import BeautifulSoup
import zipfile
from os import listdir
from os.path import isfile, join
import spacy
from spacy.lang import en
from io import BytesIO
from google.cloud import storage
import time

#heading_style=['Heading2','Heading1']
#heading_name=['Background','DEVELOPMENT DETAILS' , "“To Be” Requirements", "FUNCTIONAL REQUIREMENTS"]#'2895600-91497150DEVELOPMENT DETAILS']#,'Detailed description of the enhancement']
bs_xml_content=0
data=[]
text_data = []

def keywords_load():
		wb = load_workbook(filename = 'Actions-Keywords.xlsx')
		sheet = wb['Sheet1']

		Key_Words=[]
		row_count=[]
		action=[]

		kw_col='C'
		rc_col='D'
		ac_col='B'


		row_num=2
		max_rc=sheet.max_row
		#print("Row Count = " + str(max_rc))
		for i in range(row_num,max_rc):
									 Key_Words.append(sheet[kw_col+str(i)].value)
									 row_count.append(sheet[rc_col+str(i)].value)
									 action.append(sheet[rc_col+str(i)].value)
		#print(Key_Words)
		Key_Words_stem = []
		for i in Key_Words:
				list1 = []
				words=i.split(",")
				for j in words:
						list1.append(gensim.parsing.stem_text(j))
				Key_Words_stem.append(list1)
		#print(Key_Words_stem)
		#print(action)
		return(Key_Words_stem,action)



'''
def keywords_load():
		client = storage.Client()
		#wb = load_workbook(filename = 'Actions-Keywords.xlsx')

		bucket = client.get_bucket('action_items_list_arya')  
		blob = bucket.get_blob('Actions-Keywords.xlsx')
		wb = load_workbook(filename=BytesIO(blob.download_as_string()))
		sheet = wb['Sheet1']

		Key_Words=[]
		row_count=[]
		action=[]

		kw_col='C'
		rc_col='D'
		ac_col='B'


		row_num=2
		max_rc=sheet.max_row
		#print("Row Count = " + str(max_rc))
		for i in range(row_num,max_rc):
									 Key_Words.append(sheet[kw_col+str(i)].value)
									 row_count.append(sheet[rc_col+str(i)].value)
									 action.append(sheet[rc_col+str(i)].value)
		#print(Key_Words)
		Key_Words_stem = []
		for i in Key_Words:
				list1 = []
				words=i.split(",")
				for j in words:
						list1.append(gensim.parsing.stem_text(j))
				Key_Words_stem.append(list1)
		print(Key_Words_stem)
		print(action)
		print("Done Printing")
		return(Key_Words_stem,action)

'''


def get_accuracy(document,Key_Words_stem,action):

	nlp = spacy.load("en_core_web_sm")
	print("inside get_accuracy")
	print(document)
	#file_object  = open('Tree_test.txt', 'r')
	#document = file_object.read().lower()
	document = str(document)
	document = document.lower()
	#print("\n \n \n document")
	#print(document)cl
	list1 = []
	list2 = []
	list3 = []
	list4 = []
	start1=time.time()
	print("Creating Parent-Children Hierarchies within the text")
	print("\n \n \n ")
	document = nlp(document)
	for sente in document.sents:
		for word in sente:
			parent1 = Node(str(word))
			for child1 in list(word.children):
				child_1 = Node(str(child1), parent = parent1)        
				#print("Child 1 = " + str(child_1))
				list1.append(child_1.path[child_1.depth])
				for child2 in list(child1.children):
					#print("Child 2 = " + str(child2))
					child_2 = Node(str(child2),parent = child_1)
					list2.append(child_2.path[child_2.depth]) 		
		

	list3 = list1 + list2 
	#list3=list2
	
	list3 = set(list3)
	print("Created and Joined")
	print("\n \n \n ")
	#print("Printing List 3")
	#print(list3)
	print("\n \n \n ")
	end1=time.time()

	print("TIME TAKEN TO CREATE HIERARCHIES (s)")
	print(end1-start1)
	print("\n \n \n ")

	#print(list3)
	###########################Code for Searching##############################
	#Key_Words_stem, action =  keywords_load()
	#print(Key_Words_stem)

	count_row_keyword = []
	count_match = []
	#print("Printing The Stemmed Keywords")
	#print(Key_Words_stem)
	print("\n \n \n ")

	start1=time.time()
	for word in Key_Words_stem:
			#print((word))
			count_row_keyword.append(len(word))
			counter_3 = 0
			for wo in word:
				numberofkeywords=len(wo.split(" "))
				for i in list3:
					flagger=0
					if(numberofkeywords==1):
						if(wo in str(i)):
							counter_3+=1
							break

					if(numberofkeywords>2):																		
						if(wo.split(" ")[0] in str(i) and wo.split(" ")[1] in str(i) ):
							if(numberofkeywords==2):								
								counter_3+=1
								break

							for count in range(2,numberofkeywords):
								if(wo.split(" ")[count] in str(i)):
									flagger=2
									
								else:
									flagger=1
									break
									
							if(flagger==2):
								counter_3+=1
					

								
							
			count_match.append(counter_3)

	accuracy = []
	accuracy = [x/y for x, y in zip(count_match, count_row_keyword)]
	accuracy_keyword = dict(zip(action,accuracy))
	#print("456")
	#print(accuracy_keyword)
	end1=time.time()
	print("TIME TAKEN TO SEARCH (s)")
	print(end1-start1)
	print("\n \n \n ")

	return(accuracy_keyword)


def get_probability(acc):
		out = []
		stro = {}
		#print("accuarcy is " + str(acc).encode('utf-8'))
		for word in (sorted(acc.items() , key=lambda item: (item[1], item[0]), reverse=True)):

				#print(word)
				out.append({"Action_ID":word[0], "Probability":word[1]})
		return(out)



"""def extract_me(filename_doc): 
		global data_path
		global req_out
		global heading_style
		global heading_name
		global bs_xml_content
		global data
		doc_type = "docx"  # type of file to search 

		documents = zipfile.ZipFile(filename_doc)  # working in zip mode
		xml_path = "word/document.xml"  # master xml containing all data
		raw_xml_content = documents.read(xml_path)  # reading the xml document
		bs_xml_content = BeautifulSoup(raw_xml_content,'xml')  # using bs for parsing
		#print(str(bs_xml_content).encode('utf-8'))
		letscheckdata = extract_text_section()
		#print("letscheckdata")
		#print(letscheckdata)
		return letscheckdata
"""

@app.route('/api', methods=['POST'])
def input():

		print("Fetching Content")
		content = request.get_json()
		#print("Printing Content Below:")
		#print(content)
		#print("Printed Content")
		acc = content['ext_data']
		print("Printing the Content to analyse")
		print(acc)

		print("Starting ML")
		start = time.time()
		accuracy1 = get_accuracy(acc, Key_Words_stem,action)
		#print("123")
		type_fs = {'type_fs':'N/A'}
		#print(get_probability(accuracy1))
		end = time.time()
		print("TIME TAKEN")
		print(end - start)
		return jsonify(type_fs,get_probability(accuracy1))

if(__name__) == '__main__':

		print("Loading Keywords")
		Key_Words_stem, action =  keywords_load()
		print("Starting Server now")
		'''
		port= int(os.getenv("PORT"))    
		app.run(host='0.0.0.0', port=port, threaded=True)
		'''
		app.run(port=5000, debug = False)
		