import pandas as pd
import gensim
#import xlrd
from collections import Counter
import time
import spacy
from anytree import Node, RenderTree, search, findall_by_attr, findall
import re
from collections import defaultdict
from math import log
from flask import Flask, render_template, request, redirect, url_for, send_from_directory, send_file, jsonify
from bs4 import BeautifulSoup
from io import BytesIO
from google.cloud import storage
import os
from os import listdir
from os.path import isfile, join

app = Flask(__name__)


def ricef_Conversion(id_1):
	if(id_1=='R' or id_1=='r'):
		return 0
	elif(id_1=='I' or id_1=='i' ):
		return 1
	elif(id_1=='C' or id_1=='c'):
		return 2
	elif(id_1=='E' or id_1=='e'):
		return 3
	elif(id_1=='F' or id_1=='f'):
		return 4


'''
    client = storage.Client()
    #wb = load_workbook(filename = 'Actions-Keywords.xlsx')
    bucket = client.get_bucket('action_items_list_arya')
    blob = bucket.get_blob('Actions-Keywords.xlsx')
    wb = load_workbook(filename=BytesIO(blob.download_as_string()))

'''

def keywords_load():
    global Snippet_collection
    client = storage.Client()
    #wb = load_workbook(filename = 'Actions-Keywords.xlsx')
    bucket = client.get_bucket('arya_ml_storage')
    blob = bucket.get_blob('snippet_matching/Actions-Keywords.xlsx')
    allSnippets = pd.read_excel(BytesIO(blob.download_as_string()))
    #allSnippets=pd.read_excel('gs://arya_ml_storage//snippet_matching//Actions-Keywords.xlsx')

    #allSnippets = pd.read_excel('C:\\Users\\shivamsrivastava\\Documents\\GitHub\\Khozo\\Actions-Keywords_1.xlsx')

    Snippet_collection['R'] = allSnippets[allSnippets["RICEF_ID"] == "R"]
    Snippet_collection['I'] = allSnippets[allSnippets["RICEF_ID"] == "I"]
    Snippet_collection['C'] = allSnippets[allSnippets["RICEF_ID"] == "C"]
    Snippet_collection['E'] = allSnippets[allSnippets["RICEF_ID"] == "E"]
    Snippet_collection['F'] = allSnippets[allSnippets["RICEF_ID"] == "F"]

    keywords_calculations(Snippet_collection['R'],'R')
    keywords_calculations(Snippet_collection['I'],'I')
    keywords_calculations(Snippet_collection['C'],'C')
    keywords_calculations(Snippet_collection['E'],'E')
    keywords_calculations(Snippet_collection['F'],'F')

###print(Snippet_collection['C'])

def keywords_calculations(dfid,rfid):
	##print("Starting the Calculations for " + rfid)
	global rowstem_global
	global guid_global
	global Key_Words_stem_global
	global keylistdict_global
	global rfidcount
	global Key_Words_stem_uncounted_global


	rfid_value=ricef_Conversion(rfid)
	action=[]
	Key_Words=[]
	action=dfid['GUID']
	Key_Words=dfid['KEY_WORDS']
	action_title=dfid['ACTIONS']
	flag_c_k=dfid['CODE_KBA']
	counter_counter=0
	counter=-1
	for t in Key_Words:

		counter_counter+=1
		###print("t value is "+str(t) + str(counter_counter))
		words=t.split(",")
		rowstem_global.append(words)
		counter+=1
		#print(words)
		#print("words it is")
		for j in words:
			#print(j)
			#j=gensim.parsing.stem_text(str(j))
			#print(j)
			#print("Printed J, UPAR")
			###print(counter)

			Key_Words_stem_global.append([])
			Key_Words_stem_uncounted_global.append([])
			j = j.strip()
			meh=gensim.parsing.stem_text(j)
			Key_Words_stem_uncounted_global[rfid_value].append(meh)
			Key_Words_stem_global[rfid_value].append([])
			Key_Words_stem_global[rfid_value][counter].append(meh)
			#Key_Words_stem_global[rfid_value].append(meh)


	#print(Key_Words_stem_global[0])
	#print("Keyworddddd")
	list2 = Counter(Key_Words_stem_uncounted_global[rfid_value])
	Key_Words_stem_uncounted_global[rfid_value] = set(Key_Words_stem_uncounted_global[rfid_value])
	###print(list2)
	max_keylist=0
	newlist1=[]
	for i in list2:

		if (i=='' or i ==' '):
			###print("Not Appending")
			continue
		else:
			keylistdict_global[rfid_value][i] = (1/list2[i])

	guid_global.append([])
	guid_global[rfid_value]=action
	###print('KeyWord List for '+str(rfid_value) + ' is:- ' +str(Key_Words))

	##print("Calculated Inverses for  " + rfid)

	##print("\n ##Printing Global Variables \n :- guid_global \n ")
	##print(guid_global)
	##print(" \n ##Printing Global Variables \n :- rowstem_global \n ")
	##print(rowstem_global)
	##print(" \n ##Printing Global Variables \n :- Key_Words_stem_global \n ")
	##print(Key_Words_stem_global)
	##print(" \n ##Printing Global Variables \n :- keylistdict_global \n ")
	##print(keylistdict_global)
	###print(" \n ##Printing Global Variables \n :- rfidcount \n")
	###print(rfidcount)
	##print(" \n ##Printing Global Variables \n :- Key_Words_stem_uncounted_global  \n")
	##print(Key_Words_stem_uncounted_global)
	##print(" \n ##Printing Global Variables \n :- Snippet_collection \n")
	##print(Snippet_collection)

	##print("-"*30 + "End of Calculations" + "-"*30)

def get_accuracy(document,Key_list,Key_Words_stem,action,rfid):


	print("inside get_accuracy")
	global nlp
	rfid_value=ricef_Conversion(rfid)

	document = str(document)
	document = document.lower()
	document1 = document
	###print("\n \n \n document")
	###print(document)cl
	list1 = []
	list2 = []
	list3 = []
	list4=[]
	subjectlist=[]
	subject=''
	word_count = document.split(' ')
	##print(len(word_count))
	start1=time.time()
	##print("Creating Parent-Children Hierarchies within the text")
	##print("\n \n \n ")
	document = nlp(document)	

	for sente in document.sents:		
		for word in sente:
			worddependency=word.dep_
			isStop=word.is_stop
			posword=word.pos_
			if((worddependency == 'pobj' or worddependency == 'compound' )  and  (posword =='NOUN') and  (isStop ==  'False' or isStop == False )):				
				subjectlist.append(word)
	print(subjectlist)


	for sente in document.sents:		
		for word in sente:			
			print(str(word) + ":" + str(worddependency))
			
			'''
			
			'''
			parent1 = Node(str(word))
			for child1 in list(word.children):
				child_1 = Node(str(child1), parent = parent1)
				print("Child 1 = " + str(child_1))
				list1.append(child_1.path[child_1.depth])

				for child2 in list(child1.children):
					print("Child 2 = " + str(child2))
					child_2 = Node(str(child2),parent = child_1)
					list2.append(child_2.path[child_2.depth])

					#print(child2.children)
					for child4 in list(child2.children):
						print("Child 4 = " + str(child4))
						child_4 = Node(str(child4),parent = child_2)
						list4.append(child_4.path[child_4.depth])





	list3 = list1 + list2
	print(list1)
	print(list2)
	#list3= [j for i in zip(list1,list2) for j in i] 	
	list3=list3+list4
	print("\n \n \n ")

	#list3= list3 + list4
	#list3= [j for i in zip(list3,list4) for j in i] 	
	print("LIST3:- ")
	print(list3)

	list3 = set(list3)

	#print("The List 3 (All Appends is ) :- " +str(list3))
	wor = [[]]
	v = 0
	##print("------------------------------------")
	for node_value in list3:	
		###print(node_value)
		newWord = re.sub('Node','',str(node_value))
		newWord2 = re.sub('[^A-Za-z0-9_/]', '', str(newWord))
		###print(newWord2)
		word_split = str(newWord2).split("/")
		###print("yessss")
		###print(word_split)
		val = str('')
		for wo in word_split:
			val += gensim.parsing.stem_text(wo)
			val +='#'
		for  i in subjectlist:
			val += gensim.parsing.stem_text(str(i))
			val +='#'

		wor.append([])
		wor[v].append(val.strip())
		v = v+1

	print(wor)
		###print("------------------------------------")
	##print(wor)
	##print("---------------------------------------")
	##print("Created and Joined")
	##print("\n \n \n ")
	###print("##Printing List 3")
	###print(list3)
	##print("\n \n \n ")
	end1=time.time()

	##print("TIME TAKEN TO CREATE HIERARCHIES (s)")
	##print(end1-start1)
	##print("\n \n \n ")

	###print(list3)
	###########################Code for Searching##############################
	#Key_Words_stem, action =  keywords_load()
	###print(Key_Words_stem)

	count_row_keyword = []
	count_match = []
	#print("##Printing The Stemmed Keywords")
	#print(Key_Words_stem)
	##print("\n \n \n ")



	start1=time.time()
	count1 = defaultdict(int)
	for word in Key_Words_stem:
		#print(word)
		if(len(word)>0):
			count_row_keyword.append(len(word))
		counter_3 = 0
		numberofkeywords=len(word.split(" "))
		for i in wor: #DG
			#print("i value is "+str(i))
			for k in i:  #k= DG
				#print("##Printing Document word (k)" + str(k))
				flagger=0
				if(numberofkeywords==1):
					word1 = ''
					word1 = '#'+word+'#'
					###print("yessss")
					#print("yessssssssss "+str(word1))
					if(word1 in str(k)):
						counter_3+=1
						###print("word is "+word1)
						###print("node is "+str(i))
						count1[word]+=1
						###print(count1[word])
						###print(count1)
						#break
						continue

				else:

					if(numberofkeywords>=2):
						word_1 = ''
						word_1 ='#'+word.split(" ")[0]+'#'
						word_2 = ''
						word_2 ='#'+ word.split(" ")[1]+'#'
						if((word_1 in str(k)) & (word_2 in str(k))):

							print("2 keyword word is "+str(word))

							###print("node is 12 "+str(i))
							if(numberofkeywords==2):
								counter_3+=1
								count1[word]+=1
								continue
							#break

							for count in range(2,numberofkeywords):
								if(('#'+word.split(" ")[count]+'#') in str(k)):
									flagger=2

								else:
									flagger=1
									break

							if(flagger==2):
								counter_3+=1
								##print('\n')
								##print("node is 123 "+str(k))
								##print("word is "+str(word))
								##print(" -------------------------")
								count1[word]+=1


		count_match.append(counter_3)
	##print("-------------------------------------------")
	##print("C1 NPH")
	##print(count1.items())
	##print("C1 UPH")
	##print(count_match)
	maxme=0
	final_answer=[]
	final_answer_text=[]
	dd={}

	for key,value in count1.items():
		if(key==''):
			continue
		###print("Key Word:- " + str(key))
		###print("key:-  "  + str(Key_list[key]))
		###print("Value:-  "  + str(value))
		dd[key] = (1/log(len(word_count)))*(log(value+1))*(Key_list[key])
		#dd[key] = (1/log(len(word_count)))*(log(value+1))*(Key_list[key])
		if(int(dd[key])>maxme):
			maxme=dd[key]
		###print(Key_list[key])
		###print(key + str(value))
		###print(key +' :- ' + str(dd))
		###print("##PRINTED")

	###print(max(dd))
	##print("------------------------------- Keyword Stem Global ------------------------------")
	##print(Key_Words_stem_global[ricef_Conversion(rfid)])
	##print("------------------------------- Keyword Stem Global ------------------------------")
	print("------Printing the Dictionary (Trees Node Matched Score)-------")
	print(dd)
	for i in Key_Words_stem_global[ricef_Conversion(rfid)]:
		if not i:
			continue
		counter_g=0
		sum1=0
		counter=0
		sum_inverse=0
		#print("##Printing Sum for " + str(i))
		for j in i:
			counter_g+=1
			#print("j value is: "+str(j))
			if(j in dd):
				sum1+=dd.get(j)
				sum_inverse+=Key_list[j]
				##print(dd.get(j))
				#print("##Printing Sum for " + str(i))
				#print(sum1)
				#print(dd)
				#print(sum_inverse)
				counter+=1
				#Sum IDF of J

		###print("Appending " + str(counter_g) + str(i) )

		if (counter==0):
			counter=1

		if (sum_inverse==0):
			sum_inverse=1

			#continue
		final_answer.append((sum1/(sum_inverse/counter)))
		final_answer_text.append(i)
		if sum1!=0:

			print("\n")
			print("\n")
			print("TF* IDF Score of the row " +str(i)+ " is "+str(sum1))
			print("\n")
			print("after Matched "+str(counter)+" / " +str(counter_g)+" (Total Keywords) " +str((sum1/counter_g)*(counter)))
			print("\n")
			print("The Score after Normalizing by avging with the matched inverses " + str(sum1/(sum_inverse/counter)))
			print("\n")
			print("The Score after Normalizing by Multiplying matched inverses " + str(sum1*(sum_inverse/counter)))
			print("\n")
			print("\n")
			#print("value of each row "+ str(final_answer)+str(final_answer_text))
		#print("\n")

	##print("##Printing Global Variables \n GUID: WORDS \n")
	##print(str(guid_global) + ': ' + str(rowstem_global))
	##print(str(len(final_answer))+ '\n')
	##print("##Printing Final Answers")
	#maxme=(max(final_answer))
	###print(maxme)
	##print(final_answer)
	dd=dict(zip(guid_global[ricef_Conversion(rfid)],final_answer))


	end1=time.time()
	print("TIME TAKEN TO SEARCH AND ##PRINT (s)")
	print(end1-start1)
	print("\n \n \n ")
	print(final_answer)
	##print("\n \n \n ")
	#accuracy = [x/y for x, y in zip(count_match, count_row_keyword)]
	#accuracy_keyword = dict(zip(action,accuracy))
	###print(accuracy_keyword)
	return (dd,maxme)
	#return(accuracy_keyword)

def html_to_plain(acc):
    #Parse HTML text
    soup = BeautifulSoup(acc, 'html.parser')
    #Pop delete all h1 .. h6, strong
    #neg = soup.find_all(re.compile('^h[1-6]$|strong'))
    #for a in neg: a.decompose()
    t = soup.get_text(strip=False)
    #print("Printing .get_text")
    #print(t)

    #Replace \n with spaces -> all consecutive spaces with single space
    t = re.sub('\n+','.',t).strip()
    t = re.sub('(\.+[\s*\.*]*)','. ',t).strip()
    return t

@app.route('/api', methods=['POST'])
def input_1():
		global keylistdict_global
		global Key_Words_stem_global
		global guid_global
		global Key_Words_stem_uncounted_global
		print("Fetching Content")
		content = request.get_json()
		acc = content['ext_data']
		rfid= content['fs_typ']
		#acc='Hi this is a FS on Code snippet, here is a word ALV and then there is MM01'
		#rfid='R'
		##print("##Printing the Content to analyse")
		##print(acc)

		###print("##Printing Global Variables \n GUID: WORDS \n")
		###print(str(guid_global) + ': ' + str(rowstem_global) + '\n')
		print("--------------------------CONVERTING RICH TEXT TO PLAIN-------------------------------------")
		acc = html_to_plain(acc)
		print(acc)
		print("--------------------------TEXT CONVERTED-----------------------------------------------------")

		print("Starting ML")
		start = time.time()
		accuracy1,maxValue = get_accuracy(acc,keylistdict_global[ricef_Conversion(rfid)], Key_Words_stem_uncounted_global[ricef_Conversion(rfid)],guid_global[ricef_Conversion(rfid)],rfid)
		###print("123")
		print("Caluclated Hierarchies and Relations")
		type_fs = {'type_fs':'N/A'}
		#print(get_probability(accuracy1))
		end = time.time()
		print("TIME TAKEN \n \n ")
		print(end - start)
		return jsonify(get_probability(accuracy1,maxValue,rfid))


def get_probability(acc,maxValue,rfid):
		###print("Getting the Probability Now (Max Normalization)!")
		rank = 0
		out = []
		stro = {}

		#print("HEHEERRREEEE")
		#print(acc)
		#print(maxValue)
		#print("HEHEERRREEEE")
		####print("accuarcy is " + str(acc).encode('utf-8'))
		#print(Snippet_collection)
		for word in (sorted(acc.items() , key=lambda item: (item[1], item[0]), reverse=True)):

				snippet_temps=Snippet_collection[rfid]
				kwtemp=snippet_temps[snippet_temps["GUID"] == word[0]]
				x=",".join(kwtemp['KEY_WORDS'].values)
				t=" ".join(kwtemp['ACTIONS'].values)
				c_k=" ".join(kwtemp['CODE_KBA'].values)
				#print(x)
				if word[1] != 0:
						rank = rank + 1
						out.append({"Action_ID":word[0], "Rank":rank , "Key_Words":x, "Title":t, "Sub_type": c_k})

		#print(out)
		return(out)


@app.after_request
def after_request(response):
    header = response.headers
    header['Access-Control-Allow-Origin'] = '*'
    header['Access-Control-Allow-Headers'] = 'Origin, Content-Type, Accept'
    header['Access-Control-Allow-Credentials'] = 'true'
    return response


if(__name__) == '__main__':
	Snippet_collection = {}
	rowstem_global=[]
	Key_Words_stem_global=[]
	NumberOfIDs=5
	keylistdict_global = [dict() for x in range(NumberOfIDs)] #keylist
	guid_global=[]
	Key_Words_stem_uncounted_global=[] #Key_Words_stem
	print("Calculating Key Word Importance")
	keywords_load()
	print("Loading Spacy Small")
	nlp = spacy.load("en_core_web_lg")
	print("Starting Server")
	#port= int(os.getenv("PORT"))
	#app.run(host='0.0.0.0', port=port, threaded=True)
	app.run(port=5000, debug = False)
