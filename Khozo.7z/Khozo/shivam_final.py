from anytree import Node, RenderTree, search, findall_by_attr, findall 
from openpyxl import load_workbook
import spacy
from spacy.lang import en
import gensim
from gensim import parsing
from flask import Flask, render_template, request, redirect, url_for, send_from_directory, send_file, jsonify
app = Flask(__name__)
import os
#from flask import Flask, render_template, request, redirect, url_for, send_from_directory, send_file, jsonify
import re
from glob import glob
import re
import os
from bs4 import BeautifulSoup
import zipfile
from os import listdir
from os.path import isfile, join
import spacy
from spacy.lang import en
from io import BytesIO
from google.cloud import storage
import time
from collections import Counter
from collections import defaultdict
from fuzzywuzzy import fuzz
from math import log

bs_xml_content=0
data=[]
text_data = []

guid_global=[]
rowstem_global=[]
Key_Words_stem_global=[]

def keywords_load_all():
	

def keywords_load_R():
		
		wb = load_workbook(filename = 'Actions-Keywords_1.xlsx')
		sheet = wb['Sheet1']
		global guid_global
		global rowstem_global
		global Key_Words_stem_global

		Key_Words=[]
		action=[]
		Key_Words_Count=[]
		rc_col='C' #Key WOrds
		ac_col='D' #GUID

		row_num=2
		#max_rc=sheet.max_row
		max_rc=189
		print("Row Count = " + str(max_rc))
		Key_Words_stem = []
		for i in range(row_num,max_rc+1):
			print("i value is "+str(i))
			Key_Words.append(sheet[rc_col+str(i)].value)
			action.append(sheet[ac_col+str(i)].value)
		counter=-1
		counter_counter=0
		for t in Key_Words:
			counter_counter+=1
			print("t value is "+str(t) + str(counter_counter))
			words=t.split(",")
			rowstem_global.append(words)
			counter+=1
			for j in words:
				Key_Words_stem_global.append([])
				j = j.strip()
				meh=gensim.parsing.stem_text(j)
				Key_Words_stem.append(meh)
				Key_Words_stem_global[counter].append(meh)

		Key_list = {}
		
		list2 = Counter(Key_Words_stem)
		Key_Words_stem = set(Key_Words_stem)
		print(list2)
		max_keylist=0
		newlist1=[]
		for i in list2:
			if (i=='' or i ==' '):
				print("Not Appending")
				continue
			else:
				Key_list[i] = (1/list2[i])

		guid_global=action

		print('KeyWord List '+str(Key_Words))
	
		return(Key_list,Key_Words_stem,action)

def get_accuracy(document,Key_list,Key_Words_stem,action):

	#nlp = spacy.load("en_core_web_sm")
	#LoAd Spacy ON top
	print("inside get_accuracy")
	global nlp

	document = str(document)
	document = document.lower()
	document1 = document
	#print("\n \n \n document")
	#print(document)cl
	list1 = []
	list2 = []
	list3 = []
	word_count = document.split(' ')
	print(len(word_count))
	start1=time.time()
	print("Creating Parent-Children Hierarchies within the text")
	print("\n \n \n ")
	document = nlp(document)
	for sente in document.sents:
		for word in sente:
			parent1 = Node(str(word))
			for child1 in list(word.children):
				child_1 = Node(str(child1), parent = parent1)        
				#print("Child 1 = " + str(child_1))
				list1.append(child_1.path[child_1.depth])

				for child2 in list(child1.children):
					#print("Child 2 = " + str(child2))
					child_2 = Node(str(child2),parent = child_1)
					list2.append(child_2.path[child_2.depth]) 		
		

	list3 = list1 + list2 
	#list3=list2
	
	list3 = set(list3)
	#print(list3)
	wor = [[]]
	v = 0
	print("------------------------------------")
	for node_value in list3:
		#print(node_value)
		newWord = re.sub('Node','',str(node_value))
		newWord2 = re.sub('[^A-Za-z0-9/]', '', str(newWord))
		#print(newWord2)
		word_split = str(newWord2).split("/")
		#print("yessss")
		#print(word_split)
		val = str('')
		for wo in word_split:
			
			val += gensim.parsing.stem_text(wo)
			val +='#'
			
		wor.append([])
		wor[v].append(val.strip())
		v = v+1

		#print(wor)
		#print("------------------------------------")
	print(wor)
	print("---------------------------------------")	
	print("Created and Joined")
	print("\n \n \n ")
	#print("Printing List 3")
	#print(list3)
	print("\n \n \n ")
	end1=time.time()

	print("TIME TAKEN TO CREATE HIERARCHIES (s)")
	print(end1-start1)
	print("\n \n \n ")

	#print(list3)
	###########################Code for Searching##############################
	#Key_Words_stem, action =  keywords_load()
	#print(Key_Words_stem)

	count_row_keyword = []
	count_match = []
	#print("Printing The Stemmed Keywords")
	#print(Key_Words_stem)
	print("\n \n \n ")



	start1=time.time()
	count1 = defaultdict(int)
	for word in Key_Words_stem:
		if(len(word)>0):
			count_row_keyword.append(len(word))
		counter_3 = 0
		numberofkeywords=len(word.split(" "))
		for i in wor:
			#print("i value is "+str(i))
			for k in i:
				#print("Printing Document word " + str(k))
				flagger=0
				if(numberofkeywords==1):
					word1 = ''
					word1 = '#'+word+'#'
					#print("yessss")
					#print("yessssssssss "+str(word1))
					if(word1 in str(k)):
						counter_3+=1
						#print("word is "+word1)
						#print("node is "+str(i))
						count1[word]+=1
						#print(count1[word])
						#print(count1)
						#break
						continue

				else:
				
					if(numberofkeywords>=2):
						word_1 = ''
						word_1 ='#'+word.split(" ")[0]+'#'
						word_2 = ''
						word_2 ='#'+ word.split(" ")[1]+'#'
						if((word_1 in str(k)) & (word_2 in str(k))):
							
							#print("2 keyword word is "+str(word))								
							
							#print("node is 12 "+str(i))
							if(numberofkeywords==2):
								counter_3+=1
								count1[word]+=1
								continue
							#break

							for count in range(2,numberofkeywords):
								if(('#'+word.split(" ")[count]+'#') in str(k)):
									flagger=2
									
								else:
									flagger=1
									break
									
							if(flagger==2):
								counter_3+=1
								print('\n')
								print("node is 123 "+str(k))
								print("word is "+str(word))
								print(" -------------------------")
								count1[word]+=1
								
							
		count_match.append(counter_3)
	print("-------------------------------------------")
	print("C1 NPH")
	print(count1.items())
	print("C1 UPH")
	print(count_match)
	maxme=0
	final_answer=[]
	final_answer_text=[]
	dd={}

	
	for key,value in count1.items():
		if(key==''):
			continue
		#print("Key Word:- " + str(key))
		#print("key:-  "  + str(Key_list[key]))
		#print("Value:-  "  + str(value))
		dd[key] = (1/log(len(word_count)))*(log(value+1))*(Key_list[key])
		#dd[key] = (1/log(len(word_count)))*(log(value+1))*(Key_list[key])
		if(int(dd[key])>maxme):
			maxme=dd[key]
		#print(Key_list[key])
		#print(key + str(value))
		#print(key +' :- ' + str(dd))
		#print("PRINTED")

	#print(max(dd))
	print("------------------------------- Keyword Stem Global ------------------------------")
	print(Key_Words_stem_global)
	print("------------------------------- Keyword Stem Global ------------------------------")
	print("Printing the Dictionary")
	print(dd)	
	for i in Key_Words_stem_global:
		if not i:
			continue
		counter_g=0		
		sum1=0
		counter=0
		sum_inverse=0

		for j in i:
			counter_g+=1
			#print("j value is: "+str(j))
			if(j in dd):
				sum1+=dd.get(j)
				sum_inverse+=Key_list[j]
				#print(dd.get(j))
				#print("Printing Sum for " + str(i))
				#print(sum1)
				counter+=1
				#Sum IDF of J  

		#print("Appending " + str(counter_g) + str(i) )
		
		if (counter==0):
			counter=1

		if (sum_inverse==0):
			sum_inverse=1

			#continue

		print("\n")
		print("\n")
		print("TF* IDF Score of the row " +str(i)+ " is "+str(sum1))
		final_answer.append((sum1/(sum_inverse/counter)))
		print("\n")
		print("after Matched "+str(counter)+" / " +str(counter_g)+" (Total Keywords) " +str((sum1/counter_g)*(counter)))		
		final_answer_text.append(i)
		print("\n")
		print("The Score after Normalizing by avging with the matched inverses " + str(sum1/(sum_inverse/counter)))
		print("\n")
		print("The Score after Normalizing by Multiplying matched inverses " + str(sum1*(sum_inverse/counter)))
		print("\n")
		print("\n")
		print("value of each row "+ str(final_answer)+str(final_answer_text))
		print("\n")

	print("Printing Global Variables \n GUID: WORDS \n")
	print(str(guid_global) + ': ' + str(rowstem_global))
	print(str(len(final_answer))+ '\n')
	print("Printing Final Answers")
	#maxme=(max(final_answer))
	#print(maxme)
	dd=dict(zip(guid_global,final_answer))



		

	

	end1=time.time()
	print("TIME TAKEN TO SEARCH AND PRINT (s)")
	print(end1-start1)
	print("\n \n \n ")
	#print(final_answer)
	print("\n \n \n ")
	#accuracy = [x/y for x, y in zip(count_match, count_row_keyword)]
	#accuracy_keyword = dict(zip(action,accuracy))
	#print(accuracy_keyword)
	return (dd,maxme)
	#return(accuracy_keyword)


def get_probability(acc,maxValue):
		print("Getting the Probability Now (Max Normalization)!")	
		out = []
		stro = {}
		#print("accuarcy is " + str(acc).encode('utf-8'))
		for word in (sorted(acc.items() , key=lambda item: (item[1], item[0]), reverse=True)):

				#print(word)
				out.append({"Action_ID":word[0], "Probability":(word[1])})
		return(out)

@app.route('/api', methods=['POST'])
def input():

		print("Fetching Content")
		content = request.get_json()
		#print("Printing Content Below:")
		#print(content)
		#print("Printed Content")
		acc = content['ext_data']
		rfid= content['fs_typ']
		print("Printing the Content to analyse")
		print(acc)

		#print("Printing Global Variables \n GUID: WORDS \n")
		#print(str(guid_global) + ': ' + str(rowstem_global) + '\n')

		print("Starting ML")
		start = time.time()
		accuracy1,maxValue = get_accuracy(acc,Key_list, Key_Words_stem,action)
		#print("123")
		print("Caluclated Hierarchies and Relations")
		type_fs = {'type_fs':'N/A'}
		#print(get_probability(accuracy1))
		end = time.time()
		print("TIME TAKEN \n \n ")

		print(end - start)


		return jsonify(type_fs,get_probability(accuracy1,maxValue))

if(__name__) == '__main__':

		print("Loading Keywords")
		Key_list, Key_Words_stem, action =  keywords_load()		
		print("Keywords Loaded, Loading Spacy")
		nlp = spacy.load("en_core_web_lg")
		print("Starting Server now")

		'''
		port= int(os.getenv("PORT"))    
		app.run(host='0.0.0.0', port=port, threaded=True)
		'''
		app.run(port=5000, debug = False)
		