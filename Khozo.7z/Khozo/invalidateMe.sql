PROCEDURE "E-SSRIVA"."WIP.E-SSRIVA::PRC_VALIDATE_DATES" ( IN tableName nvarchar(20) default 'EKET',IN valueID nvarchar(20) default 'EBELN',IN schemaID nvarchar(20) default 'S4H_NA') 
	LANGUAGE SQLSCRIPT
	SQL SECURITY INVOKER 
	--DEFAULT SCHEMA <default_schema_name>
	AS
BEGIN

declare varDateFields nvarchar (40);
declare sqlStatement1 nvarchar (5000); 
declare varZero nvarchar(10);
declare varZero_s nvarchar(10);
declare dateColumnNamesArray NVARCHAR(50) ARRAY;
DECLARE INDEX INTEGER;

varZero:='''00000000''';
varZero_s:='''0''';
--select :tableName from DUMMY;

----------------FINDS ALL THE DATE-TYPE COLUMNS IN THE GIVEN TABLE----------------
dateColumns=select COLUMN_NAME , COMMENTS  from TABLE_COLUMNS where "LENGTH"='8' and (DATA_TYPE_NAME='NVARCHAR' OR DATA_TYPE_NAME='STRING') and TABLE_NAME=:tableName and (COMMENTS like '%date%' or COMMENTS like '%Date%') ;

select * from :dateColumns;

dateColumnNamesArray = ARRAY_AGG(:dateColumns.COLUMN_NAME);

varDateFields:=:dateColumnNamesArray[1];
sqlStatement1:='select '||:valueID||', '||:varDateFields||' AS "DATE"  , '''||:varDateFields||''' AS "COLUMN_NAME"  from "'||:schemaID||'"."'||:tableName||'" where '||:varDateFields||' !='||:varZero||' and dats_is_valid('||:varDateFields||')= 0 and '||:varDateFields||' !='||:varZero_s||' ' ;

--varDateFields:='ZZISDA';
----------------THE BELO LINE OF CODE CREATES A DYNAMIC SQL IN ORDER TO CHECK THE DATES OF THESE COLUMNS FOUND ABOVE----------------
FOR INDEX IN 2 .. CARDINALITY(:dateColumnNamesArray) DO
varDateFields:=:dateColumnNamesArray[:INDEX];
--SELECT :varDateFields FROM dummy;
sqlStatement1:=concat(:sqlStatement1,' UNION select '||:valueID||', '||:varDateFields||' AS "DATE" , '''||:varDateFields||''' AS "COLUMN_NAME"  from "'||:schemaID||'"."'||:tableName||'" where '||:varDateFields||' !='||:varZero||' and '||:varDateFields||' !='||:varZero_s||' and dats_is_valid('||:varDateFields||')= 0' ) ;
END FOR;
--select sqlStatement1 from DUMMY;
----------------THIS IS THE PIECE OF CODE THAT EXECUTES THE ABOVE FORMED SQL QUERY----------------
EXECUTE IMMEDIATE  sqlStatement1 ;
END;

