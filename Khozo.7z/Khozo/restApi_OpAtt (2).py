from anytree import Node, RenderTree, search, findall_by_attr, findall 
from openpyxl import load_workbook
import spacy
from spacy.lang import en
import gensim
from gensim import parsing
from flask import Flask, render_template, request, redirect, url_for, send_from_directory, send_file, jsonify
app = Flask(__name__)
import os
#from flask import Flask, render_template, request, redirect, url_for, send_from_directory, send_file, jsonify
import re
from glob import glob

import os
from bs4 import BeautifulSoup
import zipfile
from os import listdir
from os.path import isfile, join
import spacy
from spacy.lang import en
from io import BytesIO
from google.cloud import storage
import time
from collections import Counter
from collections import defaultdict
#heading_style=['Heading2','Heading1']
#heading_name=['Background','DEVELOPMENT DETAILS' , "“To Be” Requirements", "FUNCTIONAL REQUIREMENTS"]#'2895600-91497150DEVELOPMENT DETAILS']#,'Detailed description of the enhancement']
bs_xml_content=0
data=[]
text_data = []

guid_global=[]
rowstem_global=[]
Key_Words_stem_global=[]


def keywords_load():
		'''wb = load_workbook(filename = 'Actions-Keywords.xlsx')
		sheet = wb['Sheet1']

		Key_Words=[]
		row_count=[]
		action=[]

		kw_col='C'
		rc_col='D'
		ac_col='B'


		row_num=2
		max_rc=sheet.max_row
		##print("Row Count = " + str(max_rc))
		for i in range(row_num,max_rc):
									 Key_Words.append(sheet[kw_col+str(i)].value)
									 row_count.append(sheet[rc_col+str(i)].value)
									 action.append(sheet[ac_col+str(i)].value)
		##print(Key_Words)
		Key_Words_stem = []
		for i in Key_Words:
				list1 = []
				words=i.split(",")
				for j in words:
					#print(j)
					#list1.append(gensim.parsing.stem_text(j))
					Key_Words_stem.append(gensim.parsing.stem_text(j))
		##print(Key_Words_stem)
		##print(action)

		Key_Words_stem = set(Key_Words_stem)
		#print("Keyword Stem is -------------------------------------------------")
		#print(Key_Words_stem)
		return(Key_Words_stem,action)'''
		wb = load_workbook(filename = 'Actions-Keywords_1.xlsx')
		sheet = wb['Sheet1']
		global guid_global
		global rowstem_global
		global Key_Words_stem_global

		Key_Words=[]
		action=[]
		Key_Words_Count=[]
		rc_col='C' #Key WOrds
		ac_col='D' #GUID

		row_num=2
		max_rc=sheet.max_row
		##print("Row Count = " + str(max_rc))
		Key_Words_stem = []
		for i in range(row_num,max_rc):
			#pp = sheet[rc_col+str(i)].value
			Key_Words.append(sheet[rc_col+str(i)].value)
			action.append(sheet[ac_col+str(i)].value)
		counter=-1
		for t in Key_Words:
			words=t.split(",")
			rowstem_global.append(words)
			counter+=1
			for j in words:
				Key_Words_stem_global.append([])
				##print(j)
				j = j.strip()
				meh=gensim.parsing.stem_text(j)
				Key_Words_stem.append(meh)
				Key_Words_stem_global[counter].append(meh)

		Key_list = {}
		
		list2 = Counter(Key_Words_stem)
		Key_Words_stem = set(Key_Words_stem)
		#print(list2)
		max_keylist=0
		newlist1=[]
		for i in list2:
			##print('############')
			##print(i)
			
			if (i=='' or i ==' '):
				#print("Not Appending")
				continue
			else:
				Key_list[i] = (1/list2[i])
			'''
			if(Key_list[i]>=max_keylist):
				max_keylist=Key_list[i]
		for i in list2:
			newlist1.append((Key_list[i]/max_keylist))
			'''

		#print("----------------------------------------")
		#print("KEY LIST:")
		#print(Key_list)
		#print("Key_Words_stem:")
		#print(Key_Words_stem)
		#print("Action:")
		#print(action)

		guid_global=action
		##print(max_keylist)
		##print("FINAL ANSWER IS...... ")
		##print(newlist1)
		#print("----------------------------------------")

		



		return(Key_list,Key_Words_stem,action)



		#Check Dictionary's OPtim (Dicti or 2 list?) 


def get_accuracy(document,Key_list,Key_Words_stem,action):

	print("--" *30 +"Key List"+ "--" *30)
	print("\n")
	print(Key_list)
	print("--" *30 +"Key Words Stem" +"--" *30)
	print("\n")
	print(Key_Words_stem)
	print("--" *30 +"Action"+ "--" *30)
	print("\n")
	print(action)

	nlp = spacy.load("en_core_web_sm")
	#print("inside get_accuracy")
	##print(document)
	#file_object  = open('Tree_test.txt', 'r')
	#document = file_object.read().lower()
	document = str(document)
	document = document.lower()
	document1 = document
	##print("\n \n \n document")
	##print(document)cl
	list1 = []
	list2 = []
	list3 = []
	
	start1=time.time()
	#print("Creating Parent-Children Hierarchies within the text")
	#print("\n \n \n ")
	document = nlp(document)
	for sente in document.sents:
		for word in sente:
			parent1 = Node(str(word))
			for child1 in list(word.children):
				child_1 = Node(str(child1), parent = parent1)        
				##print("Child 1 = " + str(child_1))
				list1.append(child_1.path[child_1.depth])

				for child2 in list(child1.children):
					##print("Child 2 = " + str(child2))
					child_2 = Node(str(child2),parent = child_1)
					list2.append(child_2.path[child_2.depth]) 		
		

	list3 = list1 + list2 
	#list3=list2
	
	list3 = set(list3)
	#print("Created and Joined")
	#print("\n \n \n ")
	##print("#printing List 3")
	##print(list3)
	#print("\n \n \n ")
	end1=time.time()

	#print("TIME TAKEN TO CREATE HIERARCHIES (s)")
	#print(end1-start1)
	#print("\n \n \n ")

	##print(list3)
	###########################Code for Searching##############################
	#Key_Words_stem, action =  keywords_load()
	##print(Key_Words_stem)

	count_row_keyword = []
	count_match = []
	##print("#printing The Stemmed Keywords")
	##print(Key_Words_stem)
	#print("\n \n \n ")



	start1=time.time()
	count1 = defaultdict(int)
	##print("Keywords are ")
	##print(Key_Words_stem)
	for word in Key_Words_stem:
		##print("#printing Words in Key WOrds Stem")
		##print(word)
		if(len(word)>0):
			count_row_keyword.append(len(word))
		counter_3 = 0
		##print("word is "+str(word))
		#count1[wo]= document1.count(wo)
		numberofkeywords=len(word.split(" "))
		for i in list3:
			##print("#printing Document word " + str(i))
			flagger=0
			if(numberofkeywords==1):
				##print("yessss")
				if(word in str(i)):
					counter_3+=1
					##print("node is "+str(i))
					count1[word]+=1
					##print("word is "+wo)
					##print(count1[word])
					##print(count1)
					#break
					continue

			else:																	
				if(word.split(" ")[0] in str(i) and word.split(" ")[1] in str(i) ):
					if(numberofkeywords==2):
						##print("2 keyword word is "+str(word))								
						counter_3+=1
						##print("node is 123 "+str(i))
						count1[word]+=1
						continue
						#break

					for count in range(2,numberofkeywords):
						if(word.split(" ")[count] in str(i)):
							flagger=2
							
						else:
							flagger=1
							break
							
					if(flagger==2):
						counter_3+=1
						count1[word]+=1
					

								
							
		count_match.append(counter_3)
	#print("-------------------------------------------")
	#print("C1 NPH")
	#print(count1.items())
	#print("C1 UPH")
	#print(count_match)
	maxme=0
	final_answer=[]
	final_answer_text=[]
	dd={}

	
	for key,value in count1.items():
		if(key==''):
			continue
		##print("Key Word:- " + str(key))
		##print("key:-  "  + str(Key_list[key]))
		##print("Value:-  "  + str(value))
		dd[key] = (Key_list[key])*(value)
		if(int(dd[key])>maxme):
			maxme=dd[key]
		##print(Key_list[key])
		##print(key + str(value))
		##print(key +' :- ' + str(dd))
		##print("#printED")

	##print(max(dd))
	
	##print(len(Key_Words_stem_global))
	counter_g=0
	for i in Key_Words_stem_global:
		if not i:
			continue
		counter_g+=1		
		sum1=0
		counter=1
		for j in i:
			##print(j)
			if(j in dd):
				sum1+=dd.get(j)
				##print("#printing Sum for " + str(i))
				##print(sum1)
			counter+=1
		##print("Appending " + str(counter_g) + str(i) )
		final_answer.append(sum1/counter)
		final_answer_text.append(i)

	#print("#printing Global Variables \n GUID: WORDS \n")
	#print(str(len(guid_global)) + ': ' + str(len(rowstem_global)))
	#print(str(len(final_answer))+ '\n')
	#print("#printing Final Answers")
	maxme=(max(final_answer))
	#print(maxme)
	dd=dict(zip(guid_global,final_answer))



		

	

	end1=time.time()
	#print("TIME TAKEN TO SEARCH AND #print (s)")
	#print(end1-start1)
	#print("\n \n \n ")
	##print(final_answer)
	#print("\n \n \n ")
	#accuracy = [x/y for x, y in zip(count_match, count_row_keyword)]
	#accuracy_keyword = dict(zip(action,accuracy))
	##print(accuracy_keyword)
	return (dd,maxme)
	#return(accuracy_keyword)


def get_probability(acc,maxValue):
		#print("Getting the Probability Now (Max Normalization)!")	
		out = []
		stro = {}
		##print("accuarcy is " + str(acc).encode('utf-8'))
		for word in (sorted(acc.items() , key=lambda item: (item[1], item[0]), reverse=True)):

				##print(word)
				out.append({"Action_ID":word[0], "Probability":((word[1]/maxValue)*100)})
		return(out)

@app.route('/api', methods=['POST'])
def input():

		#print("Fetching Content")
		content = request.get_json()
		##print("#printing Content Below:")
		##print(content)
		##print("#printed Content")
		acc = content['ext_data']
		#print("#printing the Content to analyse")
		#print(acc)

		##print("#printing Global Variables \n GUID: WORDS \n")
		##print(str(guid_global) + ': ' + str(rowstem_global) + '\n')

		#print("Starting ML")
		start = time.time()
		accuracy1,maxValue = get_accuracy(acc,Key_list, Key_Words_stem,action)
		##print("123")
		#print("Caluclated Hierarchies and Relations")
		type_fs = {'type_fs':'N/A'}
		##print(get_probability(accuracy1))
		end = time.time()
		#print("TIME TAKEN \n \n ")

		#print(end - start)


		return jsonify(type_fs,get_probability(accuracy1,maxValue))

if(__name__) == '__main__':

		#print("Loading Keywords")
		Key_list, Key_Words_stem, action =  keywords_load()
		#print("Starting Server now")
		'''
		port= int(os.getenv("PORT"))    
		app.run(host='0.0.0.0', port=port, threaded=True)
		'''
		app.run(port=5000, debug = False)
		