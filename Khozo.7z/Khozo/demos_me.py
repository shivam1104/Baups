#Loading Libraries
from openpyxl import load_workbook
import spacy
from spacy.lang import en
import gensim
from gensim import parsing
from flask import Flask, render_template, request, redirect, url_for, send_from_directory, send_file, jsonify
app = Flask(__name__)
import os
#from flask import Flask, render_template, request, redirect, url_for, send_from_directory, send_file, jsonify
import re
from glob import glob

import os
from bs4 import BeautifulSoup
import zipfile
from os import listdir
from os.path import isfile, join
import spacy
from spacy.lang import en

heading_style=['Heading2','Heading1']
heading_name=['Background','DEVELOPMENT DETAILS' , "“To Be” Requirements", "FUNCTIONAL REQUIREMENTS"]#'2895600-91497150DEVELOPMENT DETAILS']#,'Detailed description of the enhancement']
bs_xml_content=0
data=[]
text_data = []

def keywords_load():
    wb = load_workbook(filename = 'Actions-Keywords.xlsx')
    sheet = wb['Sheet1']

    Key_Words=[]
    row_count=[]
    action=[]

    kw_col='C'
    rc_col='D'
    ac_col='B'


    row_num=2
    max_rc=sheet.max_row
    print("Row Count = " + str(max_rc))
    for i in range(row_num,max_rc):
                   Key_Words.append(sheet[kw_col+str(i)].value)
                   row_count.append(sheet[rc_col+str(i)].value)
                   action.append(sheet[ac_col+str(i)].value)
    #print(Key_Words)
    Key_Words_stem = []
    for i in Key_Words:
        list1 = []
        words=i.split(",")
        for j in words:
            list1.append(gensim.parsing.stem_text(j))
        Key_Words_stem.append(list1)
    #print(Key_Words_stem)
    #print(action)
    return(Key_Words_stem,action)


def get_accuracy(document,Key_Words_stem,action):
    #Reading and Stemming Document
              nlp = spacy.load("en")
              document = str(document)
              print("\n \n \n document")
              #print(document)
              document = document.lower()
              document_stem = document
              document_stem = gensim.parsing.stem_text(document_stem) #Stemmed Document
              # Converting document to spacy
              document = nlp(document)
              document_stem = nlp(document_stem)


              #Storing Stemmed words to be searched
              searched_word=[]
              for llist in Key_Words_stem:
                  for words in llist:
                          wor=words.split()
                          for wo in wor:
                              searched_word.append(wo)

              searched_word = set(searched_word)
              #print(searched_word)


              #Searching for stemmed word in sentences of Stemmed Document and storing corresponding orginial sentences in list
              sentences_final = []
              counter_1 = []
              counter = -1
              for word in searched_word:
                  counter = -1
                  for sente in document_stem.sents:
                      counter+=1
                      if(word in str(sente)):
                          counter_1.append(counter)

              counter_1 = set(counter_1)
              #print(counter_1)

              counter_2 = -1
              for sente in document.sents:
                  counter_2+=1
                  if(counter_2 in counter_1):
                      sentences_final.append(sente)     #sentences_final has list of sentences in which keywords are present.
              #print(sentences_final)    


              #Dependency Graph for sentences in sentences_final
              keywords_to_search = []
              for sente in sentences_final:
                  for word in sente:
                      #print(word, ': ', str(list(word.children)))
                      keywords_to_search.append( gensim.parsing.stem_text(str(word)))
                      for wor in list(word.children):
                          parent = gensim.parsing.stem_text(str(word))
                          child = gensim.parsing.stem_text(str(wor))
                          #print(str(parent)+" "+str(child))
                          #print(str(parent))
                          #keywords_to_search.append(str(parent))
                          keywords_to_search.append(str(parent)+" "+str(child))
                          keywords_to_search.append(str(child)+" "+str(parent))
                          '''for child2 in list(wor.children):
                              child_2 = gensim.parsing.stem_text(str(child2))
                              keywords_to_search.append(str(parent)+" "+str(child_2))
              '''
              keywords_to_search = set(keywords_to_search)         
              #print(keywords_to_search)


              counter_3 = 0
              count_match = []
              count_row_keyword = []
              for key_words in Key_Words_stem:
                  counter_3 = 0
                  count_row_keyword.append(len(key_words))
                  for key_search in keywords_to_search:
                      if(key_search in key_words):
                          #print(key_search)
                          counter_3+=1
                  count_match.append(counter_3)
                  #print("counter for "+str(key_words)+" counter is "+str(counter_3))
              accuracy = []
              accuracy = [x/y for x, y in zip(count_match, count_row_keyword)]
              accuracy_keyword = dict(zip(action,accuracy))
              return(accuracy_keyword)


def get_probability(acc):
    out = []
    stro = {}
    #print("accuarcy is " + str(acc).encode('utf-8'))
    for word in (sorted(acc.items() , key=lambda item: (item[1], item[0]), reverse=True)):

        #print(word)
        out.append({"Action Name ":word[0], "Probability ":word[1]})
    return(out)


def extract_text_section():
              global data_path
              global req_out
              global heading_style
              global heading_name
              global bs_xml_content
              global text_data
              #global file12

              '''Extract data from section'''
              #text_data = []
              start = False
              list12=[]
              for i in bs_xml_content.find_all("w:p"):
                  if not start:
                      for j in i.find_all("w:pStyle"):
                          #print(str(i.text).encode('utf-8'))
                          #print("Meh ")
                          print("WOW:-  "  + str(j.get("w:val").encode('cp850')))
                          list12.append(i.text.strip())
                          list12.append(" \n ")
                          list12.append(j.get("w:val"))
                          list12.append(" NEWWW NEWW NEWW")

                          #print("And Name:- ")
                          #print((str(i.text).encode('cp850')))
                          if (((j.get("w:val") == heading_style[0]) or (j.get("w:val") == heading_style[1])) and ((  [s for s in heading_name if s in  i.text.strip() ]  ))):
                              #
                              heading=j.get("w:val")
                              #print(str(i.text).encode('utf-8'))
                              #print("-------------------------MEEHHHH \n \n --------------------------------")
                              start = True

                  else:
                      if len(i.find_all("w:pStyle")) > 0:
                          for j in i.find_all("w:pStyle"):
                              if j.get("w:val") ==  heading:
                                  #return text_data                        
                                  start=False
                                  break
                              else:
                                  text_data.append(i.text)
                      else:
                          text_data.append(i.text)                
                          #print(str(i.text).encode('utf-8'))
                          
              return text_data



def extract_me(filename_doc): 
    global data_path
    global req_out
    global heading_style
    global heading_name
    global bs_xml_content
    global data
    doc_type = "docx"  # type of file to search 

    documents = zipfile.ZipFile(filename_doc)  # working in zip mode
    xml_path = "word/document.xml"  # master xml containing all data
    raw_xml_content = documents.read(xml_path)  # reading the xml document
    bs_xml_content = BeautifulSoup(raw_xml_content,'xml')  # using bs for parsing
    #print(str(bs_xml_content).encode('utf-8'))
    letscheckdata = extract_text_section()
    print("letscheckdata")
    #print(letscheckdata)
    return letscheckdata


@app.route('/api', methods=['POST'])
def input():
    print("In Input 1234")
    file = request.files['test']
    print("In Input 1234")
    acc = extract_me(file.filename)
    accuracy1 = get_accuracy(acc, Key_Words_stem,action)
    return jsonify(get_probability(accuracy1))

if(__name__) == '__main__':
    print("Loading Keywords")
    Key_Words_stem, action =  keywords_load()
    print("Starting Server now")
    app.run(port=5000, debug = False)
